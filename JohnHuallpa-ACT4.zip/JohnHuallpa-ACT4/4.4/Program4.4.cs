﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4._4
{
    class P4
    {
        static void Main(String[] args)
        {
            int n_cuenta;
            int saldo;
            int SumAcr = 0;
            while (true)
            {
                Console.Write("ingresa su número de cuenta: ");
                n_cuenta = int.Parse(Console.ReadLine());
                if (n_cuenta < 0)
                    break;
                Console.Write("Ingresa saldo de la cuenta: ");
                saldo = int.Parse(Console.ReadLine());
                if (saldo > 0)
                {
                    Console.WriteLine("Estado: Acreedor");
                    SumAcr++;
                }
                else if (saldo < 0)
                {
                    Console.WriteLine("Estado: Deudor");
                }
                else {
                    Console.WriteLine("Estado: Nulo");
                }
                Console.WriteLine();
            }
            Console.WriteLine("Total de Acreedores= " + SumAcr);
        }
    }
}