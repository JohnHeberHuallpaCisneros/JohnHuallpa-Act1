﻿// Realizar la carga del lado de un cuadrado, mostrar por pantalla el perímetro del mismo
// (El perímetro de un cuadrado se calcula multiplicando el valor del lado por cuatro).

using System;

namespace Punto1_Perimetros
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Cálculo del perímetro de un cuadrado ===\n");
            Console.Write("Ingrese la medida de un lado del cuadrado: ");
            if (double.TryParse(Console.ReadLine(), out double lado) && lado > 0)
            {
                double perimetro = lado * 4;
                Console.WriteLine($"\nEl perímetro del cuadrado es: {perimetro:F2}");
            }
            else
            {
                Console.WriteLine("Valor no valido, introduce valor positivo ");
            }
            Console.WriteLine("\nPresiona cualquier tecla para salir.");
            Console.ReadKey();
        }
    }
}