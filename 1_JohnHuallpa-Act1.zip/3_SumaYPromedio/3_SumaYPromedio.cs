﻿// Actividad 3: Realizar un programa que lea cuatro valores numéricos 
// e informar su suma y promedio.

using System;

namespace Punto3_SumaYPromedio
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Suma y promedio de 4 números ===\n");
            double suma = 0;
            for (int i = 1; i <= 4; i++)
            {
                Console.Write($"Ingrese el número {i}: ");
                suma += Convert.ToDouble(Console.ReadLine());
            }
            double promedio = suma / 4;
            Console.WriteLine($"\nSuma total: {suma}");
            Console.WriteLine($"Promedio: {promedio:F2}");
            Console.WriteLine("\nPresiona una tecla para salir.");
            Console.ReadKey();
        }
    }
}