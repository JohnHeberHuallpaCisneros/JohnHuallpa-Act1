﻿// Actividad 4: Se debe desarrollar un programa que pida el ingreso del precio 
// de un artículo y la cantidad que lleva el cliente. 
// Mostrar lo que debe abonar el comprador.

using System;

namespace Punto4_PrecioTotalArticulo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Cálculo del monto a total ===\n");
            Console.Write("Ingrese el precio de unidad del artículo: ");
            double precio = Convert.ToDouble(Console.ReadLine());

            Console.Write("Ingresar la cantidad del cliente: ");
            int cantidad = Convert.ToInt32(Console.ReadLine());

            double total = precio * cantidad;

            Console.WriteLine($"\nEl cliente debe pagar: ${total:F2}");
            Console.WriteLine("\nPresiona una tecla para salir.");
            Console.ReadKey();
        }
    }
}