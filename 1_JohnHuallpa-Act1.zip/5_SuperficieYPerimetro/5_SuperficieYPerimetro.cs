﻿// Actividad 5: Realizar la carga del radio de un círculo, 
// mostrar por pantalla la circunferencia y el área del mismo.
// (circunferencia = 2 * π * radio)    (área = π * radio²)

using System;

namespace Punto5_SuperficieYPerimetro
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Cálculos de un círculo ===\n");
            Console.Write("Ingresar radio del círculo: ");
            if (double.TryParse(Console.ReadLine(), out double radio) && radio > 0)
            {
                double circunferencia = 2 * Math.PI * radio;
                double area = Math.PI * radio * radio;

                Console.WriteLine($"\nCircunferencia: {circunferencia:F4}");
                Console.WriteLine($"Área: {area:F4}");
            }
            else
            {
                Console.WriteLine("El radio debe ser positivo.");
            }
            Console.WriteLine("\nPresiona una tecla para salir.");
            Console.ReadKey();
        }
    }
}