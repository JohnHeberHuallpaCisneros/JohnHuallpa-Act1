﻿// Actividad 2: Escribir un programa en el cual se ingresen cuatro números, 
// calcular e informar la suma de los dos primeros y el producto del tercero y el cuarto.

using System;

namespace Punto2_SumaYProducto
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Suma de los dos primeros y producto de los dos últimos ===\n");

            Console.Write("Ingrese el 1er número: ");
            double n1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Ingrese el 2do número: ");
            double n2 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Ingrese el 3ro número: ");
            double n3 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Ingrese el 4to número: ");
            double n4 = Convert.ToDouble(Console.ReadLine());
            double suma = n1 + n2;
            double producto = n3 * n4;

            Console.WriteLine($"\nSuma de los dos primeros: {suma}");
            Console.WriteLine($"Producto de los dos últimos: {producto}");

            Console.WriteLine("\nPresione una tecla para salir...");
            Console.ReadKey();
        }
    }
}