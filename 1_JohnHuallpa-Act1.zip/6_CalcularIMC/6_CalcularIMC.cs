﻿// Actividad 6: Escribir un programa que lea el peso (en kilogramos) 
// y la altura (en metros) de una persona, 
// y mostrar por pantalla su índice de masa corporal (IMC)
// IMC = peso / (altura * altura)

using System;

namespace Punto6_CalcularIMC
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Cálculo del IMC===\n");
            Console.Write("Ingrese su peso en kg: ");
            double peso = Convert.ToDouble(Console.ReadLine());

            Console.Write("Ingrese su altura en metros (puede tener ','): ");
            double altura = Convert.ToDouble(Console.ReadLine());
            if (altura <= 0 || peso <= 0)
            {
                Console.WriteLine("Los valores deben ser positivos.");
                return;
            }
            double imc = peso / (altura * altura);

            Console.WriteLine($"\nSu IMC es: {imc:F2}");
            Console.WriteLine("\nPresiona una tecla para salir.");
            Console.ReadKey();
        }
    }
}