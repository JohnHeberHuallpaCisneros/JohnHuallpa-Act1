﻿// 4. Se cargan por teclado tres números distintos. 
// Mostrar por pantalla el mayor de ellos.

using System;

namespace Punto4___MayorDeTresNumeros
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Mayor de tres números distintos ===\n");

            Console.Write("Ingrese el primer número: ");
            if (!double.TryParse(Console.ReadLine(), out double a)) { Console.WriteLine("Valor inválido"); 
                return; }

            Console.Write("Ingrese el segundo número: ");
            if (!double.TryParse(Console.ReadLine(), out double b)) { Console.WriteLine("Valor inválido");
                return; }

            Console.Write("Ingrese el tercer número: ");
            if (!double.TryParse(Console.ReadLine(), out double c)) { Console.WriteLine("Valor inválido");
                return; }

            // Verificamos que sean distintos (como pide la consigna)
            if (a == b || a == c || b == c)
            {
                Console.WriteLine("\nLos números deben ser distintos.");
                return;
            }

            double mayor = a;

            if (b > mayor) mayor = b;
            if (c > mayor) mayor = c;

            Console.WriteLine($"\nEl mayor es: {mayor}");

            Console.WriteLine("\nPresiona una tecla para salir");
            Console.ReadKey();
        }
    }
}