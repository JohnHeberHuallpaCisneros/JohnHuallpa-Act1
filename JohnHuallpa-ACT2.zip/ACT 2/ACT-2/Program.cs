﻿// 1. Realizar un programa que lea por teclado dos números, 
// si el primero es mayor al segundo informar su suma y diferencia, 
// en caso contrario informar el producto y la división del primero respecto al segundo.

using System;
namespace P1_MayorSumaDiferencia
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Comparación de dos números ===\n");

            Console.Write("Ingrese el primer número: ");
            if (!double.TryParse(Console.ReadLine(), out double a))
            {
                Console.WriteLine("Valor no valido.");
                return;
            }

            Console.Write("Ingrese el segundo número: ");
            if (!double.TryParse(Console.ReadLine(), out double b))
            {
                Console.WriteLine("Valor no valido.");
                return;
            }

            if (a > b)
            {
                double suma = a + b;
                double diferencia = a - b;
                Console.WriteLine($"\nEl primero es mayor.");
                Console.WriteLine($"Suma:        {suma:F2}");
                Console.WriteLine($"Diferencia:  {diferencia:F2}");
            }
            else if (a < b)
            {
                double producto = a * b;
                double division = (b != 0) ? a / b : double.NaN;

                Console.WriteLine($"\nEl segundo es mayor (o igual).");
                Console.WriteLine($"Producto:    {producto:F2}");

                if (b == 0)
                    Console.WriteLine("División:    No se puede dividir por cero");
                else
                    Console.WriteLine($"División:    {division:F2}");
            }
            else
            {
                Console.WriteLine("\nLos números son iguales.");
            }

            Console.WriteLine("\nPresiona una tecla para salir.");
            Console.ReadKey();
        }
    }
}