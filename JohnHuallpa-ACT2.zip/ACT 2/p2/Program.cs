﻿// 2. Se ingresan seis notas de un alumno, 
// si el promedio es mayor o igual a siete mostrar un mensaje "Promocionado"

using System;

namespace P2_Promediodnotas
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Promedio de 6 notas ===\n");

            double suma = 0;
            int notasValidas = 0;

            for (int i = 1; i <= 6; i++)
            {
                Console.Write($"Ingresa la nota {i} (0-10): ");
                if (double.TryParse(Console.ReadLine(), out double nota) && nota >= 0 && nota <= 10)
                {
                    suma += nota;
                    notasValidas++;
                }
                else
                {
                    Console.WriteLine("Nota inválida, ignorada.");
                    i--; // repetir esta nota
                }
            }

            if (notasValidas == 0)
            {
                Console.WriteLine("No se ingresaron notas válidas");
                return;
            }

            double promedio = suma / notasValidas;

            Console.WriteLine($"\nPromedio: {promedio:F2}");

            if (promedio >= 7)
                Console.WriteLine("¡Promocionado!");
            else
                Console.WriteLine("No promocionado.");

            Console.WriteLine("\nPresiona una tecla para salir");
            Console.ReadKey();
        }
    }
}